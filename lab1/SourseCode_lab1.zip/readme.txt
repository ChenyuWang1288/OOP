1. 打开Student.cpp文件，编译运行
2. Information.txt文件为测试文件（与题目中的数据一致）
3. 仅满足Information.txt与Student.cpp文件在同一路径下才可正确打开文件
4. 可以修改学生的分数，结果正确